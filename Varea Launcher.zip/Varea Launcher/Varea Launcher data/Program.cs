﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Valve.VR;
using Newtonsoft.Json;

namespace VareaLauncher
{
    class Program
    {

        static ulong mActionSetHandle;
        static ulong mActionHandleLeftB, mActionHandleRightB, mActionHandleLeftA, mActionHandleRightA, mActionHandleSystem1, mActionHandleSystem2;
        static VRActiveActionSet_t[] mActionSetArray;
        static InputDigitalActionData_t[] mActionArray;
        static bool button1Pressed, button2Pressed = false;
        static Config config = new Config();
        static string FolderLocation;
        static string jsonPath;

        // # items are referencing this list of actions: https://github.com/ValveSoftware/openvr/wiki/SteamVR-Input#getting-started
        static void Main(string[] args)
        {
            string path;
            path = System.Reflection.Assembly.GetEntryAssembly().Location.ToString();
            FolderLocation = path.Substring(0, path.IndexOf("Varea Launcher data"));

            jsonPath = FolderLocation + "\\Varea Games 2_Data\\StreamingAssets\\Options.json";

            Utils.PrintInfo(FolderLocation);
            // Initializing connection to OpenVR
            var error = EVRInitError.None;
            OpenVR.Init(ref error, EVRApplicationType.VRApplication_Background); // Had this as overlay before to get it working, but changing it back is now fine?
            var t = new Thread(Worker);
            if (error != EVRInitError.None) Utils.PrintError($"OpenVR initialization errored: {Enum.GetName(typeof(EVRInitError), error)}");
            else
            {
                Utils.PrintInfo("OpenVR initialized successfully.");

                // Load app manifest, I think this is needed for the application to show up in the input bindings at all
                Utils.PrintVerbose("Loading app.vrmanifest");
                var appError = OpenVR.Applications.AddApplicationManifest(Path.GetFullPath(FolderLocation + "\\Varea Launcher data\\app.vrmanifest"), false);
                if (appError != EVRApplicationError.None) Utils.PrintError($"Failed to load Application Manifest: {Enum.GetName(typeof(EVRApplicationError), appError)}");
                else Utils.PrintInfo("Application manifest loaded successfully.");

                // #3 Load action manifest
                Utils.PrintVerbose("Loading actions.json");
                var ioErr = OpenVR.Input.SetActionManifestPath(Path.GetFullPath(FolderLocation + "\\Varea Launcher data\\actions.json"));
                if (ioErr != EVRInputError.None) Utils.PrintError($"Failed to load Action Manifest: {Enum.GetName(typeof(EVRInputError), ioErr)}");
                else Utils.PrintInfo("Action Manifest loaded successfully.");

                // #4 Get action handles
                Utils.PrintVerbose("Getting action handles");

                var errorC1 = OpenVR.Input.GetActionHandle("/actions/default/in/left_System", ref mActionHandleSystem1);
                if (errorC1 != EVRInputError.None) Utils.PrintError($"GetActionHandle Chord1 Error: {Enum.GetName(typeof(EVRInputError), errorC1)}");
                Utils.PrintDebug($"Action Handle System 1: {mActionHandleSystem1}");

                var errorC2 = OpenVR.Input.GetActionHandle("/actions/default/in/right_System", ref mActionHandleSystem2);
                if (errorC2 != EVRInputError.None) Utils.PrintError($"GetActionHandle Chord2 Error: {Enum.GetName(typeof(EVRInputError), errorC2)}");
                Utils.PrintDebug($"Action Handle System 2: {mActionHandleSystem2}");

                // #5 Get action set handle
                Utils.PrintVerbose("Getting action set handle");
                var errorAS = OpenVR.Input.GetActionSetHandle("/actions/default", ref mActionSetHandle);
                if (errorAS != EVRInputError.None) Utils.PrintError($"GetActionSetHandle Error: {Enum.GetName(typeof(EVRInputError), errorAS)}");
                Utils.PrintDebug($"Action Set Handle default: {mActionSetHandle}");

                // Starting worker
                Utils.PrintDebug("Starting worker thread.");
                if (!t.IsAlive) t.Start();
                else Utils.PrintError("Could not start worker thread.");
            }

            Utils.PrintInfo("start");

            string json = File.ReadAllText(jsonPath);
            config = JsonConvert.DeserializeObject<Config>(json);

            //config.played = false;
            //config.childmode = false;
            JasonToFile();
            Process.Start(FolderLocation + "\\Varea Games 2.exe");
            Console.ReadLine();
            t.Abort();
            OpenVR.Shutdown();
        }

        private static void Worker()
        {
            Thread.CurrentThread.IsBackground = true;
            while (true)
            {
                // Getting events
                var vrEvents = new List<VREvent_t>();
                var vrEvent = new VREvent_t();
                try
                {
                    while (OpenVR.System.PollNextEvent(ref vrEvent, Utils.SizeOf(vrEvent)))
                    {
                        vrEvents.Add(vrEvent);
                    }
                }
                catch (Exception e)
                {
                    Utils.PrintWarning($"Could not get events: {e.Message}");
                }

                // #6 Update action set
                if(mActionSetArray == null)
                {
                    var actionSet = new VRActiveActionSet_t
                    {
                        ulActionSet = mActionSetHandle,
                        ulRestrictedToDevice = OpenVR.k_ulInvalidActionSetHandle,
                        nPriority = 0
                    };
                    mActionSetArray = new VRActiveActionSet_t[] { actionSet };
                }

                var errorUAS = OpenVR.Input.UpdateActionState(mActionSetArray, (uint)Marshal.SizeOf(typeof(VRActiveActionSet_t)));
                if (errorUAS != EVRInputError.None) Utils.PrintError($"UpdateActionState Error: {Enum.GetName(typeof(EVRInputError), errorUAS)}");

                // #7 Load input action data
                if(mActionArray == null)
                {
                    mActionArray = new InputDigitalActionData_t[] {
                        new InputDigitalActionData_t(),
                        new InputDigitalActionData_t(),
                        new InputDigitalActionData_t(),
                        new InputDigitalActionData_t(),
                        new InputDigitalActionData_t(),
                        new InputDigitalActionData_t()
                    };
                }

                ulong leftHandle = 0;
                OpenVR.Input.GetInputSourceHandle("/user/hand/left", ref leftHandle);
                ulong rightHandle = 0;
                OpenVR.Input.GetInputSourceHandle("/user/hand/right", ref rightHandle);
                var handles = new ulong[] { leftHandle, rightHandle };
                foreach(var handle in handles)
                {
                    GetDigitalInput(mActionHandleSystem1, ref mActionArray[4], handle);
                    GetDigitalInput(mActionHandleSystem2, ref mActionArray[5], handle);
                }

                // Restrict rate
                Thread.Sleep(1000 / 10);

                if (button1Pressed && button2Pressed)
                {
                    Utils.PrintInfo("start");
                    Process.Start(FolderLocation +"\\Varea Games 2.exe");
                    button2Pressed = false;
                    button1Pressed = false;

                    string json = File.ReadAllText(jsonPath);
                    config = JsonConvert.DeserializeObject<Config>(json);
                    config.played = true;
                    JasonToFile();
                }
            }
        }

        static Dictionary<ulong, EVRInputError> inputErrors = new Dictionary<ulong, EVRInputError>();

        private static void GetDigitalInput(ulong handle, ref InputDigitalActionData_t action, ulong restrict)
        {
            var size = (uint)Marshal.SizeOf(typeof(InputDigitalActionData_t));
            var error = OpenVR.Input.GetDigitalActionData(handle, ref action, size, restrict);

            // Error
            if (inputErrors.ContainsKey(handle))
            {
                if (error != inputErrors[handle] && error != EVRInputError.None)
                {
                    Utils.PrintError($"DigitalActionDataError: {Enum.GetName(typeof(EVRInputError), error)}");
                }
                inputErrors[handle] = error;
            }

            // checks if system1&2 is pressed
            if (action.bChanged == true && action.bState == true)
            {
                Utils.PrintInfo("Button got pressed: ");
                //Utils.PrintInfo($"Action {handle}, Active: {action.bActive}, State: {action.bState} on: {restrict}");
                if (handle == mActionHandleSystem1)
                {
                    button1Pressed = true;
                    Utils.PrintInfo(button1Pressed.ToString() + button2Pressed.ToString());
                    Utils.PrintInfo("system1");
                    //System.Diagnostics.Process.Start("C:\\Users\\match\\Desktop\\vtest13\\Varea Games 2.exe");
                }

                if (handle == mActionHandleSystem2)
                {
                    button2Pressed = true;
                    Utils.PrintInfo(button1Pressed.ToString() + button2Pressed.ToString());
                    Utils.PrintInfo("system2");
                }
            }
            //ches if both are up
            else if(action.bChanged && action.bState == false)
            {
                button2Pressed = false;
                button1Pressed = false;
            }
        }

        public static void JasonToFile()
        {
            string jsonend = JsonConvert.SerializeObject(config, Formatting.Indented);
            File.WriteAllText(jsonPath, jsonend);
        }
    }

    public class Config
    {
        public bool played { get; set; }
        public bool license { get; set; }
        public bool childmode { get; set; }
        public string key { get; set; }
        public string profile { get; set; }
    }
}


